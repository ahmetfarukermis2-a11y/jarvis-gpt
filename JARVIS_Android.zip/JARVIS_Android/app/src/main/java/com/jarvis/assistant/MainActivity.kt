package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

private val Navy = Color(0xFF050B16)
private val Panel = Color(0xFF0D192B)
private val Cyan = Color(0xFF56DFFF)
private val Muted = Color(0xFF9CB4CA)
private data class TaskItem(val id: String, val title: String, val done: Boolean)
private enum class OrbMode { IDLE, LISTENING, THINKING, SPEAKING }

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var onRecognized: ((String) -> Unit)? = null
    private var onModeChanged: ((OrbMode) -> Unit)? = null
    private var onStatusChanged: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        setContent { JarvisApp(this) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("tr", "TR"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    fun listen(onResult: (String) -> Unit, onMode: (OrbMode) -> Unit, onStatus: (String) -> Unit) {
        onRecognized = onResult; onModeChanged = onMode; onStatusChanged = onStatus
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onStatus("Bu cihazda konuşma tanıma servisi bulunamadı."); onMode(OrbMode.IDLE); return
        }
        val permission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!permission) { onStatus("Mikrofon izni gerekli."); onMode(OrbMode.IDLE); return }
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also { recognizer = it }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { onMode(OrbMode.LISTENING); onStatus("Dinliyorum…") }
            override fun onBeginningOfSpeech() { onMode(OrbMode.LISTENING) }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { onMode(OrbMode.THINKING); onStatus("Komut işleniyor…") }
            override fun onError(error: Int) {
                onMode(OrbMode.IDLE)
                onStatus(when(error) { SpeechRecognizer.ERROR_NO_MATCH -> "Söylediğini anlayamadım."; SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Ses servisi meşgul. Tekrar dene."; SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon izni verilmemiş."; else -> "Konuşma algılanamadı. İnternet veya konuşma hizmetini kontrol et." })
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) onRecognized?.invoke(text) else onStatus("Konuşma metne dönüştürülemedi.")
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS'e komut ver")
        }
        try { r.startListening(intent) } catch (_: Exception) { onMode(OrbMode.IDLE); onStatus("Mikrofon başlatılamadı.") }
    }

    fun speak(text: String, onMode: (OrbMode) -> Unit) {
        if (!ttsReady) { onMode(OrbMode.IDLE); Toast.makeText(this, "Türkçe ses hizmeti hazır değil; cihazın TTS ayarlarını kontrol et.", Toast.LENGTH_LONG).show(); return }
        onMode(OrbMode.SPEAKING)
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { runOnUiThread { onMode(OrbMode.IDLE) } }
            @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) { runOnUiThread { onMode(OrbMode.IDLE) } }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun openSearch(query: String) {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", query)
        try { startActivity(intent) } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(query))))
        }
    }

    override fun onDestroy() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }
}

@Composable
private fun JarvisApp(activity: MainActivity) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis_local", Activity.MODE_PRIVATE) }
    val focusManager = LocalFocusManager.current
    var input by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("JARVIS hazır. Bir komut yazabilir veya mikrofon düğmesine dokunabilirsin.") }
    var status by remember { mutableStateOf("SİSTEM HAZIR • YEREL MOD") }
    var mode by remember { mutableStateOf(OrbMode.IDLE) }
    var tasks by remember { mutableStateOf(loadTasks(prefs.getString("tasks", "[]") ?: "[]")) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) activity.listen({ input = it; handleCommand(it, tasks, { tasks = it; prefs.edit().putString("tasks", encodeTasks(it)).apply() }, { response = it }, { status = it }, { mode = it }, activity) }, { mode = it }, { status = it })
        else status = "Mikrofon izni reddedildi. Ayarlardan izin verebilirsin."
    }
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(initialValue = 0.96f, targetValue = if (mode == OrbMode.IDLE) 1.04f else 1.13f, animationSpec = infiniteRepeatable(tween(if (mode == OrbMode.THINKING) 550 else 1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071426), Navy, Color(0xFF030711)))).padding(horizontal = 18.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("J.A.R.V.I.S", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("PERSONAL AI SYSTEM", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF102A37), shape = RoundedCornerShape(30.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B6073))) {
                        Text("●  LOCAL CORE", modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("GÖREV", tasks.count { !it.done }.toString(), "bekliyor", Modifier.weight(1f))
                    MetricCard("TAMAM", tasks.count { it.done }.toString(), "kaydedildi", Modifier.weight(1f))
                    MetricCard("BAĞLANTI", "YEREL", "AI API bağlı değil", Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Text("${mode.name} MODE", color = Cyan, fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.weight(0.92f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Orb(modifier = Modifier.sizeIn(maxWidth = 320.dp, maxHeight = 320.dp).fillMaxWidth(0.82f).aspectRatio(1f).scale(pulse), mode = mode)
                }
                Text(status, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                Spacer(Modifier.height(8.dp))
                Surface(Modifier.fillMaxWidth(), color = Panel.copy(alpha = 0.95f), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B3854))) {
                    Column(Modifier.padding(14.dp)) {
                        Text("JARVIS", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text(response, color = Color(0xFFE3EFFA), fontSize = 14.sp, lineHeight = 20.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Komutunu yaz…", color = Muted) }, singleLine = true, shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { focusManager.clearFocus(); if (input.isNotBlank()) { handleCommand(input, tasks, { tasks = it; prefs.edit().putString("tasks", encodeTasks(it)).apply() }, { response = it }, { status = it }, { mode = it }, activity); input = "" } }), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF24425D), focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                    Button(onClick = { val cmd = input.trim(); if (cmd.isNotBlank()) { handleCommand(cmd, tasks, { tasks = it; prefs.edit().putString("tasks", encodeTasks(it)).apply() }, { response = it }, { status = it }, { mode = it }, activity); input = "" } }, shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(0.dp), modifier = Modifier.size(52.dp)) { Text("➤", fontSize = 22.sp) }
                    Button(onClick = { if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) activity.listen({ spoken -> input = spoken; handleCommand(spoken, tasks, { tasks = it; prefs.edit().putString("tasks", encodeTasks(it)).apply() }, { response = it }, { status = it }, { mode = it }, activity) }, { mode = it }, { status = it }) else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }, shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(52.dp)) { Text("🎙", fontSize = 19.sp) }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("GÖREVLER", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("${tasks.size} kayıt", color = Muted, fontSize = 11.sp)
                }
                if (tasks.isEmpty()) Text("Henüz görev yok. ‘Görev ekle ödevimi bitir’ diyebilirsin.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 14.dp))
                else LazyColumn(Modifier.fillMaxWidth().heightIn(max = 150.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(tasks, key = { it.id }) { task ->
                        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = task.done, onCheckedChange = { checked -> tasks = tasks.map { if (it.id == task.id) it.copy(done = checked) else it }; prefs.edit().putString("tasks", encodeTasks(tasks)).apply() }, colors = CheckboxDefaults.colors(checkedColor = Cyan, uncheckedColor = Muted))
                            Text(task.title, modifier = Modifier.weight(1f), color = if (task.done) Muted else Color.White, fontSize = 13.sp)
                            TextButton(onClick = { tasks = tasks.filterNot { it.id == task.id }; prefs.edit().putString("tasks", encodeTasks(tasks)).apply() }) { Text("Sil", color = Muted) }
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("ÖN SÜRÜM • Komutlar yerel olarak işlenir; çevrimiçi AI henüz bağlı değil.", color = Color(0xFF6F879E), fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(12.dp)).border(1.dp, Color(0xFF1A344D), RoundedCornerShape(12.dp)).padding(10.dp)) {
        Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp)); Text(value, color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(detail, color = Muted, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun Orb(modifier: Modifier = Modifier, mode: OrbMode) {
    val transition = rememberInfiniteTransition(label = "rings")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(if (mode == OrbMode.THINKING) 2200 else 9000, easing = androidx.compose.animation.core.LinearEasing)), label = "rotation")
    val glow by transition.animateFloat(0.45f, if (mode == OrbMode.SPEAKING) 0.95f else 0.7f, infiniteRepeatable(tween(if (mode == OrbMode.LISTENING) 450 else 1500), RepeatMode.Reverse), label = "glow")
    Canvas(modifier) {
        val c = center; val r = size.minDimension * 0.43f
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.15f * glow), Color(0xFF0A2440).copy(alpha = 0.5f), Color.Transparent), c, r * 1.35f), radius = r * 1.35f)
        drawCircle(Cyan.copy(alpha = 0.22f), radius = r, style = Stroke(width = 1.4.dp.toPx()))
        drawCircle(Color(0xFF2F9EC9).copy(alpha = 0.65f), radius = r * 0.83f, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, pathEffect = null))
        drawArc(Cyan.copy(alpha = 0.95f), rotation, 105f, false, topLeft = androidx.compose.ui.geometry.Offset(c.x-r*1.08f,c.y-r*1.08f), size = androidx.compose.ui.geometry.Size(r*2.16f,r*2.16f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
        drawArc(Color(0xFF1679B5).copy(alpha = 0.9f), rotation * -0.7f, 155f, false, topLeft = androidx.compose.ui.geometry.Offset(c.x-r*0.94f,c.y-r*0.94f), size = androidx.compose.ui.geometry.Size(r*1.88f,r*1.88f), style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
        drawCircle(Brush.radialGradient(listOf(Color(0xFF9BF3FF), Color(0xFF168FC9), Color(0xFF071C35)), c, r * 0.74f), radius = r * 0.72f)
        for (i in 0..27) {
            val angle = Math.toRadians((i * 360.0 / 28 + rotation * 0.35).toDouble())
            val rr = r * (0.9 + (i % 3) * 0.04)
            val x = c.x + kotlin.math.cos(angle).toFloat() * rr; val y = c.y + kotlin.math.sin(angle).toFloat() * rr
            drawCircle(Cyan.copy(alpha = 0.35f + 0.55f * glow), radius = (1.2 + (i % 3) * 0.35).dp.toPx(), center = androidx.compose.ui.geometry.Offset(x, y))
        }
        drawCircle(Color.White.copy(alpha = 0.35f), radius = r * 0.28f, center = androidx.compose.ui.geometry.Offset(c.x-r*0.2f,c.y-r*0.25f))
    }
}

private fun handleCommand(raw: String, oldTasks: List<TaskItem>, updateTasks: (List<TaskItem>) -> Unit, updateResponse: (String) -> Unit, updateStatus: (String) -> Unit, updateMode: (OrbMode) -> Unit, activity: MainActivity) {
    val command = raw.trim()
    val normalized = command.lowercase(Locale("tr", "TR")).replace("ı", "i")
    updateMode(OrbMode.THINKING); updateStatus("KOMUT ANALİZ EDİLİYOR")
    fun reply(text: String, speak: Boolean = true) { updateResponse(text); updateStatus("YEREL KOMUT MOTORU"); if (speak) activity.speak(text, updateMode) else updateMode(OrbMode.IDLE) }
    when {
        normalized.startsWith("gorev ekle") || normalized.startsWith("gorev olustur") || normalized.startsWith("hatirlat") -> {
            val title = command.substringAfter(' ', "").substringAfter(' ', "").trim().ifBlank { "Yeni görev" }
            val updated = oldTasks + TaskItem(UUID.randomUUID().toString(), title, false); updateTasks(updated)
            reply("Görevi kaydettim: $title")
        }
        normalized.contains("gorevlerim") || normalized.contains("bekleyen gorev") || normalized.contains("neler yapmam") -> {
            val pending = oldTasks.filterNot { it.done }
            reply(if (pending.isEmpty()) "Bekleyen görevin yok. Bu bölümde kayıtlı görev görünmüyor." else "Bekleyen ${pending.size} görevin var: " + pending.take(5).joinToString("; ") { it.title })
        }
        normalized.startsWith("gorev tamamla") || normalized.startsWith("tamamlandi") -> {
            val target = command.substringAfter(' ').substringAfter(' ').trim()
            val match = oldTasks.firstOrNull { it.title.contains(target, ignoreCase = true) }
            if (match == null || target.isBlank()) reply("Tamamlanacak görevi bulamadım. Görev adını ‘görev tamamla’ ifadesinden sonra yaz.")
            else { updateTasks(oldTasks.map { if (it.id == match.id) it.copy(done = true) else it }); reply("Görevi tamamlandı olarak kaydettim: ${match.title}") }
        }
        normalized.contains("bugun ne oldu") || normalized.contains("bugun ne yaptin") || normalized.contains("durum") -> {
            reply("Yerel durum özeti: ${oldTasks.count { !it.done }} bekleyen, ${oldTasks.count { it.done }} tamamlanmış görevin var. İnternet araştırması ve çevrimiçi yapay zekâ bağlantısı henüz bu sürüme bağlanmadı.")
        }
        normalized.startsWith("ara ") || normalized.startsWith("internette ara ") || normalized.startsWith("arastir ") || normalized.startsWith("internette arastir ") -> {
            val query = command.substringAfter(' ').substringAfter(' ').trim().ifBlank { command.substringAfter(' ').trim() }
            if (query.isBlank()) reply("Aramam için bir konu söyle.") else { reply("Gerçek web sonuçlarını açıyorum: $query", false); activity.openSearch(query) }
        }
        normalized.contains("youtube") -> { reply("YouTube'u açıyorum.", false); activity.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com"))) }
        normalized.contains("ayarlar") -> { reply("Android ayarlarını açıyorum.", false); activity.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
        normalized.contains("saat kac") -> reply("Şu an saat ${java.text.SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(java.util.Date())}.")
        normalized.contains("yardim") || normalized == "komutlar" -> reply("Şunları deneyebilirsin: ‘görev ekle matematik çalış’, ‘görevlerim’, ‘görev tamamla matematik çalış’, ‘internette ara uzay haberleri’, ‘YouTube aç’, ‘ayarları aç’ ve ‘bugün ne oldu’. Bu sürümde komutlar yerel kurallarla çalışıyor.")
        else -> reply("Komutunu aldım ancak bu sürümde bunun için bir işlem tanımlı değil. ‘Yardım’ diyerek desteklenen komutları öğrenebilirsin.")
    }
}

private fun encodeTasks(tasks: List<TaskItem>): String = JSONArray().apply { tasks.forEach { put(JSONObject().put("id", it.id).put("title", it.title).put("done", it.done)) } }.toString()
private fun loadTasks(json: String): List<TaskItem> = try {
    val array = JSONArray(json); (0 until array.length()).map { i -> val obj = array.getJSONObject(i); TaskItem(obj.optString("id", UUID.randomUUID().toString()), obj.optString("title", "Görev"), obj.optBoolean("done", false)) }
} catch (_: Exception) { emptyList() }
