# JARVIS Android - başlangıç sürümü

Kotlin + Jetpack Compose ile oluşturulmuş, Android üzerinde çalışan bir kişisel asistan başlangıcıdır.

## Bu sürümde bulunanlar
- Futuristik, animasyonlu JARVIS orb ve durum metni
- Android SpeechRecognizer ile Türkçe ses girişi (cihazdaki konuşma hizmetine bağlı)
- Android TextToSpeech ile Türkçe sesli yanıt (cihazdaki Türkçe TTS sesine bağlı)
- Yerel olarak kaydedilen görevler
- Görev ekleme, listeleme, tamamlandı işaretleme ve silme
- Android web aramasını açma
- Saat, YouTube ve Android ayarları için temel komutlar

## Henüz bulunmayanlar
- Bulut AI/LLM bağlantısı
- Sürekli arka planda çalışan "Hey Jarvis" uyandırma kelimesi
- Gerçek zamanlı web sayfası okuma ve kaynak özetleme
- Google Takvim, e-posta veya diğer servis entegrasyonları
- Room veritabanı, dosya içeriği indeksleme ve güvenilir arka plan görevleri

## Derleme
1. Android Studio'yu bilgisayara kur.
2. Bu klasörü Android Studio'da **Open** ile aç.
3. Gradle senkronizasyonunun bitmesini bekle.
4. Android SDK 35 ve JDK 17 kurulu değilse Android Studio'nun SDK Manager bölümünden yükle.
5. USB hata ayıklamayı açıp telefonu bağla veya bir emülatör başlat.
6. Run düğmesine bas.

İlk Gradle senkronizasyonu internet gerektirir. Bu kaynak paketi bu ortamda Android SDK/Gradle ile derlenerek test edilmemiştir; bu nedenle derleme başarısı iddia edilmemektedir.

## Desteklenen komut örnekleri
- `görev ekle matematik çalış`
- `görevlerim`
- `görev tamamla matematik çalış`
- `internette ara uzay haberleri`
- `bugün ne oldu`
- `YouTube aç`
- `ayarları aç`
- `yardım`

## Gizlilik
Görevler cihazdaki uygulama tercih alanında saklanır. Konuşma tanıma, Android'in seçtiği konuşma hizmetini kullanabilir; bu nedenle konuşmanın cihaz dışına çıkıp çıkmadığı ilgili hizmetin ayarlarına bağlıdır.
